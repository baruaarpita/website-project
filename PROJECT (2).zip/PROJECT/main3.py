from flask import Flask, render_template, request
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configure MySQL
app.config['MYSQL_HOST'] = 'MySQL80'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Ar@&1234'
app.config['MYSQL_DB'] = 'registration'

mysql = MySQL(app)

@app.route('/register', methods=['POST'])
def register():
    full_name = request.form.get('fullName')
    username = request.form.get('username')
    email = request.form.get('email')
    phone_number = request.form.get('phoneNumber')
    password = request.form.get('password')
    confirm_password = request.form.get('confirmPassword')
    gender = request.form.get('gender')

    # Perform validation here if needed

    # Store data in MySQL
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO users (full_name, username, email, phone_number, password, gender) VALUES (%s, %s, %s, %s, %s, %s)",
                (full_name, username, email, phone_number, password, gender))
    mysql.connection.commit()
    cur.close()

    return "Registration successful!"

if __name__ == '__main__':
    app.run(debug=True)
